import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class CafeKasir {
    private Map<String, List<String>> customerHistory;
    private Map<String, Integer> menuPrices;
    private Map<String, Integer> customerOrderCount;

    public CafeKasir() {
        customerHistory = new HashMap<>();
        menuPrices = new HashMap<>();
        customerOrderCount = new HashMap<>();
        initializeMenuPrices();
    }

    private void initializeMenuPrices() {
        menuPrices.put("Kopi Hitam", 10000);
        menuPrices.put("Kopi Susu", 14000);
        menuPrices.put("Cappuccino", 18000);
        menuPrices.put("Espresso", 15000);
    }

    public void startOrdering() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Apakah Anda pernah berkunjung di cafe ini sebelumnya? (ya/tidak): ");
        String answer = scanner.nextLine();

        if (answer.equalsIgnoreCase("tidak")) {
            System.out.print("Apakah Anda ingin mendaftar sebagai member? (ya/tidak): ");
            String registerAnswer = scanner.nextLine();
            if (registerAnswer.equalsIgnoreCase("ya")) {
                boolean validInput = false;
                String phoneNumber = "";
                String firstName = "";

                while (!validInput) {
                    System.out.print("Masukkan nomor telepon Anda: ");
                    phoneNumber = scanner.nextLine();
                    System.out.print("Masukkan nama depan Anda: ");
                    firstName = scanner.nextLine();
                    if (isValidPhoneNumber(phoneNumber) && isValidFirstName(firstName)) {
                        validInput = true;
                    } else {
                        System.out.println("Nomor telepon atau nama depan tidak valid.");
                    }
                }

                addNewCustomer(phoneNumber, firstName);
            } else {
                System.out.println("Silakan pesan sebagai tamu.");
                handleOrder(null);
            }
        } else if (answer.equalsIgnoreCase("ya")) {
            System.out.print("Masukkan nomor telepon Anda: ");
            String phoneNumber = scanner.nextLine();
            System.out.print("Masukkan nama depan Anda: ");
            String firstName = scanner.nextLine();
            if (phoneNumber.equals("0895700628439") && firstName.equalsIgnoreCase("wilda")) {
                addNewCustomer(phoneNumber, firstName);
            } else {
                System.out.println("Nomor telepon atau nama depan tidak valid.");
                System.out.print("Apakah Anda ingin mendaftar sebagai member? (ya/tidak): ");
                String reRegisterAnswer = scanner.nextLine();
                if (reRegisterAnswer.equalsIgnoreCase("ya")) {
                    boolean validInput = false;
                    String rePhoneNumber = "";
                    String reFirstName = "";

                    while (!validInput) {
                        System.out.print("Masukkan nomor telepon Anda: ");
                        rePhoneNumber = scanner.nextLine();
                        System.out.print("Masukkan nama depan Anda: ");
                        reFirstName = scanner.nextLine();
                        if (isValidPhoneNumber(rePhoneNumber) && isValidFirstName(reFirstName)) {
                            validInput = true;
                        } else {
                            System.out.println("Nomor telepon atau nama depan tidak valid.");
                        }
                    }

                    addNewCustomer(rePhoneNumber, reFirstName);
                } else {
                    System.out.println("Silakan pesan sebagai tamu.");
                    handleOrder(null);
                }
            }
        } else {
            System.out.println("Pilihan tidak valid.");
        }
    }

    private boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber.matches("^08\\d{9,13}$");
    }

    private boolean isValidFirstName(String firstName) {
        return firstName.matches("^[a-zA-Z]+$");
    }

    private void addNewCustomer(String phoneNumber, String firstName) {
        List<String> history = new ArrayList<>();
        customerHistory.put(phoneNumber, history);
        customerOrderCount.put(phoneNumber, 0);
        System.out.println("Selamat, Anda telah menjadi member di kafe kopi. Selamat berbelanja!");
        System.out.println();
        System.out.println("Silakan pesan menu yang Anda inginkan.");
        handleOrder(phoneNumber);
    }

    private void handleOrder(String phoneNumber) {
        Scanner scanner = new Scanner(System.in);
        int totalHarga = 0;
        int orderCount = 0;

        while (true) {
            System.out.println("\nSelamat Datang Di Kafenya Kopi Seadanya :)");
            System.out.println("Daftar Menu:");
            System.out.println("1. Kopi Hitam - Rp. 10,000");
            System.out.println("2. Kopi Susu - Rp. 14,000");
            System.out.println("3. Cappuccino - Rp. 18,000");
            System.out.println("4. Espresso - Rp. 15,000");
            System.out.println("5. Selesai");

            LocalDate currentDate = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            String transactionDate = currentDate.format(formatter);

            System.out.print("Pilih menu (masukkan nomor): ");
            int menuOption = scanner.nextInt();
            scanner.nextLine();

            String order = "";
            switch (menuOption) {
                case 1:
                    order = "Kopi Hitam";
                    totalHarga += menuPrices.get(order);
                    break;
                case 2:
                    order = "Kopi Susu";
                    totalHarga += menuPrices.get(order);
                    break;
                case 3:
                    order = "Cappuccino";
                    totalHarga += menuPrices.get(order);
                    break;
                case 4:
                    order = "Espresso";
                    totalHarga += menuPrices.get(order);
                    break;
                case 5:
                    System.out.println("Total Harga: Rp. " + totalHarga);

                    // Diskon 5% jika pelanggan telah melakukan 6 pesanan atau lebih
                    if (orderCount >= 6) {
                        double diskon = 0.05 * totalHarga;
                        double totalBayar = totalHarga - diskon;
                        System.out.println("Diskon: Rp. " + diskon);
                        System.out.println("Total Bayar (setelah diskon): Rp. " + totalBayar);
                    } else {
                        System.out.println("Total Bayar: Rp. " + totalHarga);
                    }

                    System.out.print("Jumlah uang yang dibayarkan: Rp. ");
                    int jumlahBayar = scanner.nextInt();
                    scanner.nextLine();

                    if (jumlahBayar >= totalHarga) {
                        int kembalian = jumlahBayar - totalHarga;
                        System.out.println("Kembalian: Rp. " + kembalian);
                    } else {
                        System.out.println("Jumlah uang yang dibayarkan tidak mencukupi.");
                    }

                    System.out.println("Terima kasih telah melakukan pemesanan.");

                    if (phoneNumber != null) {
                        System.out.println("History Pesanan Anda:");
                        displayTransactionHistory(phoneNumber);
                        System.out.println("Transaksi ke-" + (customerOrderCount.get(phoneNumber) + 1) + " selesai.");
                        customerOrderCount.put(phoneNumber, customerOrderCount.get(phoneNumber) + 1);
                    }
                    return;
                default:
                    System.out.println("Menu tidak valid. Silakan pilih menu yang benar.");
                    continue;
            }

            orderCount++;
            addOrder(phoneNumber, order, transactionDate);
        }
    }

    private void addOrder(String phoneNumber, String order, String transactionDate) {
        if (phoneNumber != null) {
            List<String> history = customerHistory.get(phoneNumber);
            history.add(order);
            customerHistory.put(phoneNumber, history);
            writeTransactionToFile(phoneNumber, order, transactionDate);
        }
    }

    private void displayTransactionHistory(String phoneNumber) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("transaction.txt"));
            String line;

            while ((line = reader.readLine()) != null) {
                if (line.startsWith(phoneNumber)) {
                    System.out.println("- " + line.substring(phoneNumber.length() + 2));
                }
            }

            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void writeTransactionToFile(String phoneNumber, String order, String transactionDate) {
        try {
            FileWriter writer = new FileWriter("transaction.txt", true);
            writer.write(phoneNumber + ": " + order + " - " + transactionDate + "\n");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        CafeKasir cafeKasir = new CafeKasir();
        cafeKasir.startOrdering();
    }
}
